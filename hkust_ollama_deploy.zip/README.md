config，credentials为aws cli的配置，安装aws cli后替换~/.aws下的文件即可完成aws cli的配置

terraform为infra control工具，用于本地开发中支持云服务和管理云上作业和资源

解压后，在文件所在目录运行代码如下：(应用程序架构为：darwin x64)

```{bash}
./terraform.exe init
./terraform.exe plan
./terrraform.exe apply
```

执行成功后可以在aws ec2服务中看到对应的实例

连接对应的实例，在实例中运行如下代码：

```{bash}
sudo CC=/usr/bin/gcc10-cc ./NVIDIA-Linux-x86_64*.run --tmpdir=$TMPDIR
sudo touch /etc/modprobe.d/nvidia.conf
echo "options nvidia NVreg_EnableGpuFirmware=0" | sudo tee --append /etc/modprobe.d/nvidia.conf
sudo yum install -y docker
sudo usermod -a -G docker ec2-user
sudo systemctl enable docker.service
sudo systemctl start docker.service
curl -s -L https://nvidia.github.io/libnvidia-container/stable/rpm/nvidia-container-toolkit.repo | \
sudo tee /etc/yum.repos.d/nvidia-container-toolkit.repo
sudo yum install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker
sudo docker run -d --gpus=all -v ollama:/root/.ollama -p 11434:11434 --name ollama --restart always ollama/ollama
sudo docker exec -it ollama ollama pull llama3.1:latest
sudo docker exec -it ollama ollama pull llava:latest
sudo docker run -d -p 3000:8080 --add-host=host.docker.internal:host-gateway -v ollama-webui:/app/backend/data --name ollama-webui --restart always ghcr.io/ollama-webui/ollama-webui:main
```

本地测试API连接：

```{bash}
curl http://<private-host>:11434/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "llama3.1",
        "messages": [
            {
                "role": "system",
                "content": "You are a helpful assistant."
            },
            {
                "role": "user",
                "content": "Hello!"
            }
        ]
    }'
```

